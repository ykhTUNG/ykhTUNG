$(document).ready(function(){
  $('.slider').bxSlider({
      auto: true,
      pause: 5000,
  });
});