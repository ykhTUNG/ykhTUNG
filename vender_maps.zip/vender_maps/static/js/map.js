// /* 緯度・経度と倍率の指定 */
// var mymap = L.map("mymap",{
//   center: [35.474513, 139.629342],
//   zoom: 16,
//   minZoom: 8,
//   maxZoom: 18,
//   zoomsliderControl: true,
//   zoomControl: false
// })/*.setView([35.474513, 139.629342], 16);*/
                  
                  
// /* 地図タイルとクレジット表示 */
// L.tileLayer("http://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
//     {
//       attribution: "&copy; <a href='http://osm.org/               copyright'>OpenStreetMap</a> contributors"
//     }
// ).addTo(mymap);
         
// /* イベント処理 */
// var popup = L.popup();
// function onMapClick(e){
//   /*popup.setLatLng(e.latlng).setContent(
//     "<p>緯度:" + e.latlng.lat + " 経度:" + e.latlng.lng + "</p>"
//   ).openOn(mymap);*/
//   id_EU02_latitude.value = e.latlng.lat;
//   id_EU02_longitude.value = chageLongitude(e.latlng.lng);
// }
// mymap.on("click", onMapClick)
                  
// /* 位置情報の取得に成功した時 */
// function onLocationFound(e) {
//   now = e.latlng;
//   id_EU02_latitude.value = e.latlng.lat;
//   id_EU02_longitude.value = chageLongitude(e.latlng.lng);
//   L.marker([id_EU02_latitude.value, id_EU02_longitude.value], {icon: position}).addTo(mymap).bindPopup("現在地");
// }
                  
// /* 位置情報の取得に失敗した時 */
// function onLocationError(e) {
//   alert("現在地を取得できませんでした。\n" + e.message);
// }

// /* 経度を0～360の間に設定する関数 */
// function chageLongitude(lngs) {
//   while(lngs > 360 || lngs < 0){
//     if(lngs > 360){
//       lngs -= 360;
//       alert("remove 360");
//     }
//     if(lngs < 0){
//       lngs += 360;
//       alert("add 360");
//     }
//   }
//   return lngs;
// }
                  
// mymap.on('locationfound', onLocationFound);
// mymap.on('locationerror', onLocationError);
                  
// mymap.locate({setView: true, maxZoom: 16, timeout: 20000});