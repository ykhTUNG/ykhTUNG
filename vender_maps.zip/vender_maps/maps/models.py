from django.db import models
from accounts.models import CustomUser

class EU03_company(models.Model):
  """メーカーモデル"""
  
  EU03_name = models.CharField(verbose_name='メーカー名', max_length=20)
  EU03_hp = models.CharField(verbose_name='公式サイト URL', max_length=500, blank=True, null=True)
  EU03_twitter = models.CharField(verbose_name='公式Twitter URL', max_length=500, blank=True, null=True)
  EU03_facebook = models.CharField(verbose_name='公式Facebook URL', max_length=500, blank=True, null=True)
  EU03_instagram = models.CharField(verbose_name='公式Instagram URL', max_length=500, blank=True, null=True)
  EU03_youtube = models.CharField(verbose_name='公式YouTube URL', max_length=500, blank=True, null=True)
  EU03_line = models.CharField(verbose_name='公式Line URL', max_length=500, blank=True, null=True)

  def __str__(self):
    return self.EU03_name

class EU02_vending_machine(models.Model):
  """自販機モデル"""
  SELECTION = (('0', '通常自販機'), ('1', '災害支援自販機'))
  SELECTION2 = (('0', '未承認'), ('1', '承認済み'))
  
  user = models.ForeignKey(CustomUser, verbose_name='ユーザー', on_delete=models.PROTECT)
  EU02_latitude = models.FloatField(verbose_name='緯度')
  EU02_longitude = models.FloatField(verbose_name='経度')
  EU02_company = models.ForeignKey(EU03_company, on_delete=models.CASCADE)
  EU02_company2 = models.ForeignKey(EU03_company, on_delete=models.CASCADE, null=True, blank=True, related_name='メーカー２')
  EU02_company3 = models.ForeignKey(EU03_company, on_delete=models.CASCADE, null=True, blank=True, related_name='メーカー３')
  EU02_type = models.CharField(verbose_name='自販機種類', choices=SELECTION, max_length=1, default=0)
  EU02_detail = models.TextField(verbose_name='詳細', max_length=500, null=True, blank=True)
  EU02_placename = models.CharField(verbose_name='名称', max_length=50)
  EU02_picture1 = models.ImageField(verbose_name='写真１', null=True, blank=True)
  EU02_picture2 = models.ImageField(verbose_name='写真２', null=True, blank=True)
  EU02_picture3 = models.ImageField(verbose_name='写真３', null=True, blank=True)
  EU02_created = models.DateTimeField(verbose_name='作成日時', auto_now_add=True)
  EU02_approval = models.CharField(verbose_name='管理人承認', choices=SELECTION2, max_length=1, default=0)

  class Meta:
    verbose_name_plural = 'EU02_vending_machine'

  def __str__(self):
    return self.EU02_placename