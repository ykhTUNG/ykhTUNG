from django.urls import path
from . import views

app_name = 'maps'
urlpatterns = [
  path('', views.IndexViews.as_view(), name="index"),
  path('en/', views.EnglishIndexViews.as_view(), name="en_index"),
  path('inquiry/', views.InquiryView.as_view(), name="inquiry"),
  path('post/', views.PostView.as_view(), name="post"),
  path('test/', views.TestView.as_view(), name="test"),
  path('map/', views.MapView.as_view(), name="map"),
  path('offline/', views.OfflineView.as_view(), name="staff"),
  path('staff/', views.StaffDetailView.as_view(), name="staff"),
  path('guide/', views.GuideView.as_view(), name="guide"),
  path('guide2/', views.Guide2View.as_view(), name="guide2"),
  path('cocacola/', views.CocacolaView.as_view(), name="cocacola"),
  path('mypage/', views.MyPageView.as_view(), name="mypage"),
  path('detail/<int:pk>', views.DetailView.as_view(), name="detail"),
  path('update/<int:pk>', views.UpdateView.as_view(), name="update"),
  path('delete/<int:pk>', views.DeleteView.as_view(), name="delete"),
  path('kanrisya', views.KanrisyaViews.as_view(), name="kanrisya"),
]