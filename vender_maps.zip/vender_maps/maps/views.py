import logging
from django.urls import reverse_lazy

from django.shortcuts import render
from django.views import generic
from .forms import InquiryForm, DataForm, UpdateForm
from django.contrib import messages
from django.contrib.auth.mixins import LoginRequiredMixin
from .models import EU02_vending_machine, EU03_company
from django.db.models import Q

logger = logging.getLogger(__name__)

class IndexViews(generic.ListView):
  template_name = 'index.html'
  model = EU02_vending_machine
  paginate_by = 3

  def get_queryset(self):
    diaries = EU02_vending_machine.objects.filter(Q(EU02_type=0) | Q(EU02_approval=1)).order_by('-EU02_created')
    return diaries

class EnglishIndexViews(generic.ListView):
  template_name = 'en_index.html'
  model = EU02_vending_machine
  paginate_by = 3

  def get_queryset(self):
    diaries = EU02_vending_machine.objects.filter(Q(EU02_type=0) | Q(EU02_approval=1)).order_by('-EU02_created')
    return diaries

class InquiryView(generic.FormView):
  template_name = 'inquiry.html'
  form_class = InquiryForm
  success_url = reverse_lazy('maps:inquiry')

  def form_valid(self, form):
    form.send_email()
    messages.success(self.request, 'メッセージを送信しました。')
    logger.info('Inquiry sent by {}'.format(form.cleaned_data['name']))
    return super().form_valid(form)

class PostView(LoginRequiredMixin, generic.CreateView):
  model = EU02_vending_machine
  template_name = 'post.html'
  form_class = DataForm
  success_url = reverse_lazy('maps:post')

  def get_queryset(self):
    diaries = EU02_vending_machine.objects.all().order_by('EU02_created')
    return diaries

  def form_valid(self, form):
    vender = form.save(commit=False)
    vender.user = self.request.user
    vender.save()
    messages.success(self.request, '投稿が完了しました。')
    return super().form_valid(form)

  def form_invalid(self, form):
    messages.error(self.request, '投稿に失敗しました。')
    return super().form_invalid(form)

class MapView(generic.ListView):
  model = EU02_vending_machine
  template_name = 'map.html'

  def get_queryset(self):
    diaries = EU02_vending_machine.objects.all().order_by('EU02_created')
    return diaries

  def get_context_data(self, **kwargs):
    ctx = super().get_context_data(**kwargs)
    ctx.update({
      'object_list2': EU03_company.objects.all(),
    })
    return ctx

class TestView(LoginRequiredMixin, generic.ListView):
  model = EU02_vending_machine
  template_name = 'test.html'
  form_class = DataForm

  def get_queryset(self):
    diaries = EU02_vending_machine.objects.filter(user=self.request.user).order_by('EU02_created')
    return diaries

  def get_context_data(self, **kwargs):
    ctx = super().get_context_data(**kwargs)
    ctx['company_name'] = EU03_company.objects.values('EU03_name')
    ctx['date'] = EU02_vending_machine.objects.values('EU02_created')
    ctx['post'] = EU02_vending_machine.objects.values('EU02_placename')
    ctx['test'] = EU02_vending_machine.objects.values('EU02_detail').filter(user=self.request.user)
    return ctx

class StaffDetailView(LoginRequiredMixin, generic.ListView):
  model = EU02_vending_machine
  template_name = 'staff.html'
  paginate_by = 100

  def get_queryset(self):
    q_word = self.request.GET.get('query')

    if q_word:
      object_list = EU02_vending_machine.objects.filter(Q(EU02_approval__icontains=q_word) | Q(EU02_placename__icontains=q_word))
    else:
      object_list = EU02_vending_machine.objects.all()
    return object_list
    # vender = EU02_vending_machine.objects.all().order_by('EU02_created')
    # return vender

class GuideView(generic.TemplateView):
  template_name = 'guide.html'
  
class Guide2View(generic.TemplateView):
  template_name = 'guide2.html'

class CocacolaView(generic.TemplateView):
  template_name = 'cocacola.html'

class MyPageView(LoginRequiredMixin, generic.ListView):
  model = EU02_vending_machine
  template_name = 'mypage.html'
  paginate_by = 3

  def get_queryset(self):
    Maps = EU02_vending_machine.objects.filter(user=self.request.user).order_by('-EU02_created')
    return Maps

class DetailView(generic.DetailView):
  model = EU02_vending_machine
  template_name = 'detail.html'

class UpdateView(LoginRequiredMixin, generic.UpdateView):
  model = EU02_vending_machine
  template_name = 'update.html'
  form_class = UpdateForm

  def get_success_url(self):
    return reverse_lazy('maps:detail', kwargs={'pk': self.kwargs['pk']})

  def form_valid(self, form):
    messages.success(self.request, '投稿内容を更新しました。')
    return super().form_valid(form)

  def form_invalid(self, form):
    messages.error(self.request, '投稿内容の更新に失敗しました。')
    return super().form_invalid(form)

class DeleteView(LoginRequiredMixin, generic.DeleteView):
  model = EU02_vending_machine
  template_name = 'delete.html'
  success_url = reverse_lazy('maps:mypage')

  def delete(self, request, *args, **kwargs):
    messages.success(self.request, "投稿を削除しました。")
    return super().delete(request, *args, **kwargs)

class OfflineView(generic.TemplateView):
  template_name = 'offline.html'