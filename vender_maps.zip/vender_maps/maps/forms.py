from django import forms
from django.core.mail import EmailMessage
from .models import EU02_vending_machine

# お問い合わせフォームの作成
class InquiryForm(forms.Form):
  name = forms.CharField(label='お名前', max_length=30)
  mail = forms.EmailField(label='メールアドレス')
  title = forms.CharField(label='件名', max_length=20, required=False)
  content = forms.CharField(label='内容', widget=forms.Textarea)

  def __init__(self, *args, **kwargs):
    super().__init__(*args, **kwargs)

    self.fields['name'].widget.attrs['class'] = 'form-control col-9'
    self.fields['name'].widget.attrs['placeholder'] = 'お名前をここに入力してください。'

    self.fields['mail'].widget.attrs['class'] = 'form-control col-11'
    self.fields['mail'].widget.attrs['placeholder'] = 'メールアドレスをここに入力してください。'

    self.fields['title'].widget.attrs['class'] = 'form-control col-11'
    self.fields['title'].widget.attrs['placeholder'] = '件名をここに入力してください。'

    self.fields['content'].widget.attrs['class'] = 'form-control col-12'
    self.fields['content'].widget.attrs['placeholder'] = 'お問い合わせ内容をここに入力してください。'

  def send_email(self):
    name = self.cleaned_data['name']
    mail = self.cleaned_data['mail']
    title = self.cleaned_data['title']
    content = self.cleaned_data['content']

    subject = '{0}（{1}さんからのお問い合わせ）'.format(title, name)
    subject2 = f'{name}様、お問い合わせいただきましてありがとうございます。'
    message = '送信者：{0}\nメールアドレス：{1}\nお問い合わせ内容：{2}\n'.format(name, mail, content)
    message2 = f'こちらは自販機マップ運営です。\nこの度はお問い合わせ頂きまして、誠にありがとうございます。\n\nこのメールはお問い合わせいただいたメールアドレスに自動送信しております。\nもし、このメールに心当たりがない場合はお手数ですがこのメールに心当たりがない旨を記載し返信いただきますようお願い申し上げます。\nこれからも自販機マップを何卒よろしくお願い申し上げます。\n\n\n以下の内容で受付いたしました。\n件名：{title}\n本文：{content}\n\nURL:http://127.0.0.1:8000/'

    from_email = ''
    to_list = [
      'electric.unions@gmail.com'
    ]
    cc_list = [
      mail
    ]

    message = EmailMessage(subject=subject, body=message, from_email=from_email, to=to_list)
    #message.attach_file(photo1)
    message.send()
    message2 = EmailMessage(subject=subject2, body=message2, from_email=from_email, to=cc_list)
    message2.send()

# 自販機情報登録に必要なフォーム
class DataForm(forms.ModelForm):
  class Meta:
    model = EU02_vending_machine
    fields = ('EU02_latitude', 'EU02_longitude', 'EU02_company', 'EU02_company2', 'EU02_company3', 'EU02_type', 'EU02_placename', 'EU02_detail', 'EU02_picture1', 'EU02_picture2', 'EU02_picture3',)

    def __init__(self, *args, **kwargs):
      super().__init__(*args, **kwargs)
      for field in self.fields.values():
        field.widget.attrs['class'] = 'form-control'

# ユーザーが自身で投稿した情報を変更するフォーム
class UpdateForm(forms.ModelForm):
  class Meta:
    model = EU02_vending_machine
    fields = ('EU02_company', 'EU02_company2', 'EU02_company3', 'EU02_placename', 'EU02_detail', 'EU02_picture1', 'EU02_picture2', 'EU02_picture3',)

    def __init__(self, *args, **kwargs):
      super().__init__(*args, **kwargs)
      for field in self.fields.values():
        field.widget.attrs['class'] = 'form-control'