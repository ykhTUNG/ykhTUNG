from django.contrib import admin
from .models import EU02_vending_machine, EU03_company

admin.site.register(EU02_vending_machine)
admin.site.register(EU03_company)